<?php
/* Smarty version 3.1.39, created on 2021-08-13 02:52:49
  from 'C:\xampp2\htdocs\HospitalMedico\templates\Home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6115c2616074f1_22616907',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b04ac08f71c65148ae44e595bb865a33ef66cf67' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\HospitalMedico\\templates\\Home.tpl',
      1 => 1628815968,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:Cabeceras/Header.tpl' => 1,
    'file:Cabeceras/Footer.tpl' => 1,
  ),
),false)) {
function content_6115c2616074f1_22616907 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:Cabeceras/Header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="center-align">
    <div class="container">
        <div class="card-panel blue lighten-3"><h1>¡BIENVENIDO!</h1></div>
        <div class="card-panel blue lighten-3"><h2>Elige el rol que eres...</h2></div>

        <div background= "red ligten-3"></div>
    
        <div class ="row">
            <div class="input field col s12">
            <a class="waves-effect waves-light btn-large"><i class="material-icons left">people_outline</i>Cliente</a>
            </button>
            </div>
        </div> 
        <div class ="row">
            <div class="input field col s12">
            <a class="waves-effect waves-light btn-large"><i class="material-icons left">contact_mail</i>Secretaria</a>
        </button>
            </div>
        </div> 
        <div class ="row">
            <div class="input field col s12">
            <a class="waves-effect waves-light btn-large"><i class="material-icons left">add_box</i>Doctor</a>
        </button>
            </div>
        </div> 
    </div>
</div>
    
<?php $_smarty_tpl->_subTemplateRender("file:Cabeceras/Footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
