<?php
/* Smarty version 3.1.39, created on 2021-08-13 02:24:22
  from 'C:\xampp2\htdocs\HospitalMedico\Cabeceras\Footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6115bbb64da5d2_09809189',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee2166a6b54810a4ac1cb0a5b1b9bba4ddff68b0' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\HospitalMedico\\Cabeceras\\Footer.tpl',
      1 => 1628814260,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6115bbb64da5d2_09809189 (Smarty_Internal_Template $_smarty_tpl) {
?>            <!--JavaScript at end of body for optimized loading-->
        <?php echo '<script'; ?>
 type="text/javascript" src="Framework/materialize/js/materialize.min.js"><?php echo '</script'; ?>
>
    </body>
</html><?php }
}
